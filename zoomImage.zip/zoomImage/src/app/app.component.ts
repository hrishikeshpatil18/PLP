import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  myThumbnail = 'https://via.placeholder.com/150';
  myFullresImage = 'https://via.placeholder.com/500';
}


