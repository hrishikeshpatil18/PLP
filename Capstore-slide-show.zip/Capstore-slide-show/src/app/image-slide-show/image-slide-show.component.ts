import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-slide-show',
  templateUrl: './image-slide-show.component.html',
  styleUrls: ['./image-slide-show.component.css']
})
export class ImageSlideShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
