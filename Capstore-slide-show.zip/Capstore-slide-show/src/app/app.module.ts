import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ImageSlideShowComponent } from './image-slide-show/image-slide-show.component';

@NgModule({
  declarations: [
    AppComponent,
    ImageSlideShowComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [ImageSlideShowComponent]
})
export class AppModule { }
