import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  constructor() { }

  functionCategory() {

    console.log(this.Products);

    for (var i = 0; i < this.Products.length; i++) {

      //console.log(this.Products[3].productPrice);
      this.Category.push(this.Products[i].prodCategory);
      console.log(this.Category[i]);

    }

}
